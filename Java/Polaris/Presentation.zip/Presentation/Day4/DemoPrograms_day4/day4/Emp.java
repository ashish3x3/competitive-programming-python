package com.demoprograms.day4;

public class Emp {

	private int age;
		

	public Emp(int age) {
		 
		this.age=age;
	}
	
	
	
	/*public int hashCode()
	{
		return age;
	}
	
	public boolean equals(Object ob)
	{
		boolean flag=false;
		Emp e=(Emp)ob;
		
	   	if (e.age==this.age)
		flag=true;
		return flag;
		
		 
	}
	*/
	
}
