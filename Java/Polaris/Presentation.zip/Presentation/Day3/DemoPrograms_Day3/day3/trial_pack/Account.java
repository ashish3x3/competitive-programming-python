package com.demoprograms.day3.trial_pack;
 public interface Account
	{
		
		 void Deposit(int Deposit_amount);
		 void Withdraw(int withdraw_amount);
		 void Amount_Transcation(int Transcation_amount);
		 void Available_Balance(int Account_Number, String Password);
	}