package com.demoprograms.day3;

public class Student  implements java.io.Serializable{ 
	public String name; 
	public String address; 
	public transient int rollno; 
	public  int roomNo; 
	}