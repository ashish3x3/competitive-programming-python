public class InstanceDemo{
   private int i;
   public printVariable() {
      System.out.println("Variable is:" + i);
   }
}

public static void main(String[] args) {
  InstanceDemo vt = new InstanceDemo();
   vt.printVariable();
}

 