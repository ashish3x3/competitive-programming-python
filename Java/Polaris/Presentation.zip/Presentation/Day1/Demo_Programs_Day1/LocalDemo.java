public class LocalDemo{

 
public void pupAge()
{ 
   int age=0;
   age = age+7;
   System.out.println("Puppy's age is : " + age);
 } 


public static void main(String args[]){ 

 LocalDemo test = new  LocalDemo(); 
test.pupAge();
//System.out.println(age);
 }

 } 
